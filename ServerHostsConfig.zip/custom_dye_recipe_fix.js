// Place this file in the 'kubejs/server_scripts' folder.

// Someone pointed out that green dye is uncraftable, despite purple and orange both being craftable. Never again!

ServerEvents.recipes(event => {
  event.shapeless(
    Item.of('minecraft:green_dye', 2),
    [
      'minecraft:yellow_dye',
      'minecraft:blue_dye'
    ]
  )
})