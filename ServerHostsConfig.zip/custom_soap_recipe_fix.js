// Place this file in the 'kubejs/server_scripts' folder.

// Replace the existing recipe for soap with two others: The first accepts all domestic animal fat, instead of only raw pork, without making additional tags. The second allows for a half-portion, using Farmer's Delight's special cuts. A neat side-effect is, that soap is now craftable from the player crafting grid. Go and wash yourselves!

ServerEvents.recipes(event => {
  event.remove({id: 'supplementaries:soap'})
  event.shapeless(
    Item.of('supplementaries:soap', 6),
    [
      'minecraft:water_bucket',
      '4x supplementaries:ash',
      ['minecraft:beef', 'minecraft:porkchop']
    ]
  )
  event.shapeless(
    Item.of('supplementaries:soap', 4),
    [
      'minecraft:water_bucket',
      '4x supplementaries:ash',
      'minecraft:mutton'
    ]
  )
  event.shapeless(
    Item.of('supplementaries:soap', 3),
    [
      'minecraft:water_bucket',
      '2x supplementaries:ash',
      ['farmersdelight:minced_beef', 'farmersdelight:bacon']
    ]
  )
  event.shapeless(
    Item.of('supplementaries:soap', 2),
    [
      'minecraft:water_bucket',
      '2x supplementaries:ash',
      'farmersdelight:mutton_chops'
    ]
  )
  console.log('Hello! This recipe event (supplementaries:soap adjustment) has fired!')
})