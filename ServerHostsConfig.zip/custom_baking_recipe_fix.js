// Place this file in the 'kubejs/server_scripts' folder.

// Change the existing recipes for bread, cakes and pies to require flour for dough, and dough for baked goods, which should make the flour mill relevant.

// Declare new and relevant tags
ServerEvents.tags('item', event => {
  event.add('forge:chocolate', ['create:bar_of_chocolate', 'create:chocolate_bucket'])
  event.add('forge:honey', ['minecraft:honey_bottle', 'create:honey_bucket'])
})

ServerEvents.recipes(event => {
  // Altogether removed recipes:
  event.remove({id: 'farmersdelight:wheat_dough_from_water'}) // directly from wheat
  event.remove({id: 'minecraft:cake'}) // redundant
  event.remove({id: 'create:crafting/curiosities/cake'}) // redundant
  
  // Changed recipes: ...
  // ... for Dough
  event.remove({id: 'minecraft:bread'})
  event.shaped(
    Item.of('minecraft:bread', 1),
    [
      '   ',
      'XXX',
      '   '
    ],
    {
      X: '#forge:dough'
    }
  )
  
  event.remove({id: 'create:campfire_cooking/bread'})
  event.campfireCooking('minecraft:bread', '#forge:dough', 0, 600)
  
  event.remove({id: 'farmersdelight:wheat_dough_from_egg'})
  event.shapeless(
    Item.of('farmersdelight:wheat_dough', 3),
    [
      '3x #forge:flour',
      '#forge:eggs'
    ]
  )
  
  event.remove({id: 'farmersdelight:pie_crust'})
  event.shaped(
    Item.of('farmersdelight:pie_crust', 1),
    [
      '   ',
      'ABA',
      ' A '
    ],
    {
      A: '#forge:dough',
      B: '#forge:milk',
    }
  )
  
  event.remove({id: 'createaddition:compacting/cake_base'})
  event.recipes.create.compacting('createaddition:cake_base', ['#forge:eggs', '2x minecraft:sugar', '3x #forge:dough'])
  
  // ... for Cookies
  event.remove({id: 'minecraft:cookie'})
  event.shapeless(
    Item.of('minecraft:cookie', 8),
    [
      '#forge:chocolate',
      '2x #forge:dough'
    ]
  )
  
  event.remove({id: 'farmersdelight:honey_cookie'})
  event.shapeless(
    Item.of('farmersdelight:honey_cookie', 8),
    [
      '#forge:honey',
      '2x #forge:dough'
    ]
  )
  
  event.remove({id: 'farmersdelight:sweet_berry_cookie'})
  event.shapeless(
    Item.of('farmersdelight:sweet_berry_cookie', 8),
    [
      'minecraft:sweet_berries',
      '2x #forge:dough'
    ]
  )
  
  // ... for Cakes
  event.remove({id: 'farmersdelight:cake_from_milk_bottle'})
  event.shaped(
    Item.of('minecraft:cake', 1),
    [
      'AAA',
      'BCB',
      'DDD'
    ],
    {
      A: '#forge:milk',
	  B: 'minecraft:sugar',
	  C: '#forge:eggs',
	  D: '#forge:dough'
    }
  )
  
  event.shaped(
    Item.of('createaddition:chocolate_cake', 1),
    [
      'AAA',
      'BCB',
      'DDD'
    ],
    {
      A: '#forge:chocolate',
	  B: 'minecraft:sugar',
	  C: '#forge:eggs',
	  D: '#forge:dough'
    }
  )
  
  event.shaped(
    Item.of('createaddition:honey_cake', 1),
    [
      'AAA',
      'BCB',
      'DDD'
    ],
    {
      A: '#forge:honey',
	  B: 'minecraft:sugar',
	  C: '#forge:eggs',
	  D: '#forge:dough'
    }
  )
  
  event.recipes.farmersdelight.cutting(
    'createaddition:chocolate_cake',
	'#forge:tools/knives',
	'7x farmersdelight:cake_slice'
  )
  
  event.recipes.farmersdelight.cutting(
    'createaddition:honey_cake',
	'#forge:tools/knives',
	'7x farmersdelight:cake_slice'
  )
  
  event.shapeless(
    Item.of('createaddition:chocolate_cake', 1),
	[
	  '3x #forge:chocolate',
	  ['minecraft:cake', 'createaddition:cake_base_baked']
	]
  )
  
  event.shapeless(
    Item.of('createaddition:honey_cake', 1),
	[
	  '3x #forge:honey',
	  ['minecraft:cake', 'createaddition:cake_base_baked']
	]
  )
  
  event.shapeless(
    Item.of('createaddition:honey_cake', 1),
	[
	  '3x #forge:milk',
	  'createaddition:cake_base_baked'
	]
  )
  
  // ... for Pies
  event.remove({id: 'minecraft:pumpkin_pie'})
  event.shaped(
    Item.of('minecraft:pumpkin_pie', 2),
    [
      'AAA',
      'BAB',
      'CDC'
    ],
    {
      A: 'farmersdelight:pumpkin_slice',
	  B: '#forge:eggs',
	  C: 'minecraft:sugar',
	  D: 'farmersdelight:pie_crust'
    }
  )
  
  event.remove({id: 'farmersdelight:apple_pie'})
  event.shaped(
    Item.of('farmersdelight:apple_pie', 1),
    [
      'AAA',
      'BBB',
      'CDC'
    ],
    {
      A: '#forge:dough',
	  B: 'minecraft:apple',
	  C: 'minecraft:sugar',
	  D: 'farmersdelight:pie_crust'
    }
  )
  
  event.remove({id: 'farmersdelight:chocolate_pie'})
  event.shaped(
    Item.of('farmersdelight:chocolate_pie', 1),
    [
      'AAA',
      'BBB',
      'CDC'
    ],
    {
      A: '#forge:chocolate',
	  B: '#forge:milk',
	  C: 'minecraft:sugar',
	  D: 'farmersdelight:pie_crust'
    }
  )
  
  // Other
  event.remove({id: 'strawgolem:straw_hat'})
  event.shaped(
    Item.of('strawgolem:straw_hat', 1),
    [
      '   ',
      ' X ',
      'XXX'
    ],
    {
      X: '#supplementaries:straw'
    }
  )
  
  event.remove({id: 'minecraft:packed_mud'})
  event.shapeless(
    Item.of('minecraft:packed_mud', 1),
	[
	  'minecraft:mud',
	  '#supplementaries:straw'
	]
  )
  
  console.log('Hello! This recipe event (baking fixes) has fired!')
})