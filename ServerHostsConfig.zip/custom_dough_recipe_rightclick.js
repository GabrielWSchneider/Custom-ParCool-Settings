// Place this file in the 'kubejs/server_scripts' folder.

// Someone explained how mud is crafted in vanilla. I want similar functionality to allow crafting dough by hand.

ItemEvents.rightClicked('create:wheat_flour', event => {
  if(event.target.block == 'minecraft:water' ||   // If the flour touches water, or
     event.target.block.properties.waterlogged){  // a waterlogged block, then...
	event.item.count--
    event.player.give('create:dough')
  }
})
