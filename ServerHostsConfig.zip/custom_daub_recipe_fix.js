// Place this file in the 'kubejs/server_scripts' folder.

ServerEvents.tags('item', event => {
  event.add('supplementaries:wattle_and_daubs',
	['supplementaries:daub_brace', 'supplementaries:daub_cross_brace', 'supplementaries:daub_frame'])
});