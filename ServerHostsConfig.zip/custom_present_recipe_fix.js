// Place this file in the 'kubejs/server_scripts' folder.

// Replace the existing recipe for the gift box with one that accepts *either* paper or cardboard, instead of only paper, without making a tag that specifically includes both.

ServerEvents.recipes(event => {
  event.remove({id: 'supplementaries:present'})
  event.shaped(
    Item.of('supplementaries:present', 1),
    [
      'XXX',
      'X X',
      'XXX'
    ],
    {
      X: ['create:cardboard', 'minecraft:paper']
    }
  )
  console.log('Hello! This recipe event (create:present adjustment) has fired!')
})