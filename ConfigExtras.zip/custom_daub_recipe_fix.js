ServerEvents.tags('item', event => {
	event.add('supplementaries:wattle_and_daubs', 'supplementaries:daub_brace');
	event.add('supplementaries:wattle_and_daubs', 'supplementaries:daub_cross_brace');
	event.add('supplementaries:wattle_and_daubs', 'supplementaries:daub_frame');
});